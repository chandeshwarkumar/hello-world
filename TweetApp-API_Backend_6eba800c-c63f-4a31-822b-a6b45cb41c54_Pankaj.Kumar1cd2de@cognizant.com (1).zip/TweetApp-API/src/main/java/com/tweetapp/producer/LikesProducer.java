package com.tweetapp.producer;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.tweetapp.entities.Tweet;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LikesProducer {

	private final KafkaTemplate<String, Tweet> kafkaTemplate;
	
	public void sendLikedToKafkaTopic(Tweet tweet) {
		kafkaTemplate.send("tweet-like-topic", tweet);
	}
}
