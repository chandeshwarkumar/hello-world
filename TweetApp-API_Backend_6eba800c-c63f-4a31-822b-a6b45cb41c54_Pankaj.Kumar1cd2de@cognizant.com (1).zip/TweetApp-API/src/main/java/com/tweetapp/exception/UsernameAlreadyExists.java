package com.tweetapp.exception;

public class UsernameAlreadyExists extends Exception{
	
	public UsernameAlreadyExists(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
