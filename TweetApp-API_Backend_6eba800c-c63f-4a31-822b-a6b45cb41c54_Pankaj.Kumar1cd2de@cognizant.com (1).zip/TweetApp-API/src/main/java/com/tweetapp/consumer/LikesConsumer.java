package com.tweetapp.consumer;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.tweetapp.dto.Like;
import com.tweetapp.entities.Tweet;
import com.tweetapp.repositories.TweetRepository;

@Service
public class LikesConsumer {
	
	@Autowired
	TweetRepository tweetRepository;

	@KafkaListener(topics = "${kafka.likes-topic}", groupId = "${kafka.group-id}")
	public void consumeLikesFromKafkaTopic(Tweet tweet) {
		tweetRepository.save(tweet);
	}
}
