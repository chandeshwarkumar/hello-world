import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TweetService {

  constructor(private httpClient:HttpClient) { }

  //done
  postNewTweet(postTweetForm){
    let body={
      userName: postTweetForm.value.userName,
      tweetDes: postTweetForm.value.tweetDes,
      recActive: "y"
    }
    return this.httpClient.post("http://tweetapp-env.eba-svkicfzp.us-east-2.elasticbeanstalk.com/api/v1.0/tweets/" + postTweetForm.value.userName + "/add", body);
  }

  //done
  getAllTweets(){
    return this.httpClient.get("http://tweetapp-env.eba-svkicfzp.us-east-2.elasticbeanstalk.com/api/v1.0/tweets/all");
  }

  
  replyTweet(request){
    return this.httpClient.put("http://tweetapp-env.eba-svkicfzp.us-east-2.elasticbeanstalk.com/api/v1.0/tweets/" + request.userName + "/reply/" + request.tweetId, request);
  }

  //done
  getUserTweet(){
    return this.httpClient.get("http://tweetapp-env.eba-svkicfzp.us-east-2.elasticbeanstalk.com/api/v1.0/tweets/username", {params:{userName: sessionStorage.getItem('userName')}});
  }

  //done
  deleteTweet(id){
    return this.httpClient.delete("http://tweetapp-env.eba-svkicfzp.us-east-2.elasticbeanstalk.com/api/v1.0/tweets/" + sessionStorage.getItem('userName') + "/delete/" + id);
  }

  //done
  likeTweet(id){
     return this.httpClient.put("http://tweetapp-env.eba-svkicfzp.us-east-2.elasticbeanstalk.com/api/v1.0/tweets/like/" + id,sessionStorage.getItem('userName'));
  }

  //done
  unLikeTweet(id){
    return this.httpClient.put("http://tweetapp-env.eba-svkicfzp.us-east-2.elasticbeanstalk.com/api/v1.0/tweets/unLike/" + id,sessionStorage.getItem('userName'));
 }

 //done
 updateTweet(updateTweet){
  return this.httpClient.put("http://tweetapp-env.eba-svkicfzp.us-east-2.elasticbeanstalk.com/api/v1.0/tweets/update/" + updateTweet.value.id,updateTweet.value);
 }
}
