export interface Register {
    firstName: string;
    lastName: string;
    email: string;
    userName: string;
    password: string;
    contactNum: number;
    statusMsg: string;
}